You need to download the dataset and unzip it into the "PAthreader_main/PAthreader_database" folder:
  The dataset used to run the PAthreader can be accessed through http://zhanglab-bioinf.com/PAthreader/download.html
  PAthreader generate MSA by searching the UniRef30_2020_03_hhsuite(https://wwwuser.gwdg.de/~compbiol/uniclust/) for template recognition